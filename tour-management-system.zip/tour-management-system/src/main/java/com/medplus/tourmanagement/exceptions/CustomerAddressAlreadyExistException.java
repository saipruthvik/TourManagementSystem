package com.medplus.tourmanagement.exceptions;

public class CustomerAddressAlreadyExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
