package com.medplus.tourmanagement.exceptions;

public class TicketReservationAlreadyCancelledException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
