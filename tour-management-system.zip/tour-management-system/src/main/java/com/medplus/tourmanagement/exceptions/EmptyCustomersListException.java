package com.medplus.tourmanagement.exceptions;

public class EmptyCustomersListException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
