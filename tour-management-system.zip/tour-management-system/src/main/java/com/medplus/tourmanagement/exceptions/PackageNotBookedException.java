package com.medplus.tourmanagement.exceptions;

public class PackageNotBookedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
