package com.medplus.tourmanagement.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.medplus.tourmanagement.entities.CustomerDependent;

@Repository
public interface CustomerDependentDao extends JpaRepository<CustomerDependent, Integer> {

	@Query(value = "select max(customerDependentId) from CustomerDependent")
	int getMaxCustomerDependentId();

	@Query(value = "select custDepnd from CustomerDependent custDepnd where custDepnd.customerInfo.customerId = ?1")
	List<CustomerDependent> getCustomerDependentsList(int customerId);
}
