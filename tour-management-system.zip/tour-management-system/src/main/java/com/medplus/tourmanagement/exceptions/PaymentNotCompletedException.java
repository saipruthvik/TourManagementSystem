package com.medplus.tourmanagement.exceptions;

public class PaymentNotCompletedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
