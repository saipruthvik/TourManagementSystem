package com.medplus.tourmanagement.exceptions;

public class AddressAlreadyExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3190808206663667798L;

}
