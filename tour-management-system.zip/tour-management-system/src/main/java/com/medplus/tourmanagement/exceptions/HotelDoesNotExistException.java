package com.medplus.tourmanagement.exceptions;

public class HotelDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1613003518869760601L;

}
