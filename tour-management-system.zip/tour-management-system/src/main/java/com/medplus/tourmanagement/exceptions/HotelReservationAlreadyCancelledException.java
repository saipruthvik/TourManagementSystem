package com.medplus.tourmanagement.exceptions;

public class HotelReservationAlreadyCancelledException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
