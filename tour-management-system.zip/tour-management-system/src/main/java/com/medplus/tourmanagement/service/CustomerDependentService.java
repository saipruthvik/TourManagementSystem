package com.medplus.tourmanagement.service;

import java.util.List;

import com.medplus.tourmanagement.dto.CustomerDependentDto;
import com.medplus.tourmanagement.entities.CustomerDependent;

public interface CustomerDependentService {

	CustomerDependent addCustomerDependent(CustomerDependentDto customerDependentDto);

	void deleteCustomerDependent(int customerDependentId);

	List<CustomerDependentDto> getCustomerDependentsList(int customerId);

}
