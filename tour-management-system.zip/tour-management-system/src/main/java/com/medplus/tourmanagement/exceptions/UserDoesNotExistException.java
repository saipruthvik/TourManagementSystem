package com.medplus.tourmanagement.exceptions;

public class UserDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7419880511433748482L;

}
