package com.medplus.tourmanagement.exceptions;

@SuppressWarnings("serial")
public class HotelReservationNotFoundException extends RuntimeException {

}
