package com.medplus.tourmanagement.exceptions;

public class HotelReservationDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1011023106183595898L;

}
