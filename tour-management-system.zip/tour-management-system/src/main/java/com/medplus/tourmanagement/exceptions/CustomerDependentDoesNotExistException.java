package com.medplus.tourmanagement.exceptions;

public class CustomerDependentDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5297220786394725241L;

}
