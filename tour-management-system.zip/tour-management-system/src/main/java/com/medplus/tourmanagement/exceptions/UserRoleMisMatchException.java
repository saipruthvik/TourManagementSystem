package com.medplus.tourmanagement.exceptions;

public class UserRoleMisMatchException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9076179929387615693L;

}
