package com.medplus.tourmanagement.exceptions;

public class EmptyHotelsListException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2615714784562014127L;

}
