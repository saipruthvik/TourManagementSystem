package com.medplus.tourmanagement.exceptions;

public class CustomerDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
