package com.medplus.tourmanagement.exceptions;

public class EmptyTourInformationListException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
