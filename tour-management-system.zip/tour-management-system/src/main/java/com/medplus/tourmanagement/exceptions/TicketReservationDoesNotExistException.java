package com.medplus.tourmanagement.exceptions;

public class TicketReservationDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7764393299104234822L;

}
