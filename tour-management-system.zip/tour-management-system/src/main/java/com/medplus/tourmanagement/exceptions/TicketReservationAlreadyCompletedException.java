package com.medplus.tourmanagement.exceptions;

public class TicketReservationAlreadyCompletedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
