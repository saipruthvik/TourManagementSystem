package com.medplus.tourmanagement.exceptions;

public class UserRoleDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6538741803289733146L;

}
