package com.medplus.tourmanagement.exceptions;

public class AddressDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1869474605645801022L;

}
