package com.medplus.tourmanagement.exceptions;

public class PackageReservationNotCompletedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
