package com.medplus.tourmanagement.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "customerDependent")
public class CustomerDependent {
	@Id
	private int customerDependentId;
	@ManyToOne
	@JoinColumn(name = "customerId")
	private CustomerInfo customerInfo;
	@Column(name = "customerDependentName")
	private String customerDependentName;
	@Column(name = "customerDependentAge")
	private int customerDependentAge;

	public int getCustomerDependentId() {
		return customerDependentId;
	}

	public void setCustomerDependentId(int customerDependentId) {
		this.customerDependentId = customerDependentId;
	}

	public CustomerInfo getCustomerInfo() {
		return customerInfo;
	}

	public void setCustomerInfo(CustomerInfo customerInfo) {
		this.customerInfo = customerInfo;
	}

	public String getCustomerDependentName() {
		return customerDependentName;
	}

	public void setCustomerDependentName(String customerDependentName) {
		this.customerDependentName = customerDependentName;
	}

	public int getCustomerDependentAge() {
		return customerDependentAge;
	}

	public void setCustomerDependentAge(int customerDependentAge) {
		this.customerDependentAge = customerDependentAge;
	}

}
