package com.medplus.tourmanagement.exceptions;

public class PackageCancelledException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
