package com.medplus.tourmanagement.exceptions;

public class TourCompletedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
