package com.medplus.tourmanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medplus.tourmanagement.dao.CustomerDependentDao;
import com.medplus.tourmanagement.dao.CustomerInfoDao;
import com.medplus.tourmanagement.dto.CustomerDependentDto;
import com.medplus.tourmanagement.entities.CustomerDependent;
import com.medplus.tourmanagement.entities.CustomerInfo;
import com.medplus.tourmanagement.exceptions.CustomerDependentDoesNotExistException;
import com.medplus.tourmanagement.exceptions.CustomerDoesNotExistException;

@Service
public class CustomerDependentServiceImpl implements CustomerDependentService {

	@Autowired
	CustomerDependentDao customerDependentDao;

	@Autowired
	CustomerInfoDao customerInfoDao;

	@Override
	public CustomerDependent addCustomerDependent(CustomerDependentDto customerDependentDto) {
		List<CustomerDependent> customerDependentsList = customerDependentDao.findAll();
		int customerDependentId = 0;
		if (customerDependentsList.isEmpty())
			customerDependentId = 1000;
		else {
			customerDependentId = customerDependentDao.getMaxCustomerDependentId();
			customerDependentId++;
		}
		Optional<CustomerInfo> customerInfo = customerInfoDao.findById(customerDependentDto.getCustomerId());
		if (customerInfo.isEmpty())
			throw new CustomerDoesNotExistException();
		CustomerDependent customerDependent = new CustomerDependent();
		customerDependent.setCustomerDependentId(customerDependentId);
		customerDependent.setCustomerDependentName(customerDependentDto.getCustomerDependentName());
		customerDependent.setCustomerDependentAge(customerDependentDto.getCustomerDependentAge());
		customerDependent.setCustomerInfo(customerInfo.get());
		return customerDependentDao.save(customerDependent);
	}

	@Override
	public void deleteCustomerDependent(int customerDependentId) {
		if (customerDependentDao.findById(customerDependentId).isEmpty())
			throw new CustomerDependentDoesNotExistException();
		customerDependentDao.deleteById(customerDependentId);
	}

	@Override
	public List<CustomerDependentDto> getCustomerDependentsList(int customerId) {
		Optional<CustomerInfo> customerInfo = customerInfoDao.findById(customerId);
		if (customerInfo.isEmpty())
			throw new CustomerDoesNotExistException();
		List<CustomerDependent> customerDependentsList = customerDependentDao.getCustomerDependentsList(customerId);
		List<CustomerDependentDto> customerDependentDtosList = new ArrayList<>();
		for (CustomerDependent cust : customerDependentsList) {
			CustomerDependentDto customerDependentDto = new CustomerDependentDto();
			customerDependentDto.setCustomerDependentAge(cust.getCustomerDependentAge());
			customerDependentDto.setCustomerDependentName(cust.getCustomerDependentName());
			customerDependentDto.setCustomerId(customerId);
			customerDependentDtosList.add(customerDependentDto);
		}
		return customerDependentDtosList;
	}

}
