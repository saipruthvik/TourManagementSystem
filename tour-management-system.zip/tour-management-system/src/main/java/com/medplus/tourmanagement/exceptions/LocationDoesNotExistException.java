package com.medplus.tourmanagement.exceptions;

public class LocationDoesNotExistException extends RuntimeException {

	private static final long serialVersionUID = -4003790950192591350L;

}
