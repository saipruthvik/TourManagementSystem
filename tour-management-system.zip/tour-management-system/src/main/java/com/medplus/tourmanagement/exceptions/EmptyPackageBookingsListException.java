package com.medplus.tourmanagement.exceptions;

public class EmptyPackageBookingsListException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
