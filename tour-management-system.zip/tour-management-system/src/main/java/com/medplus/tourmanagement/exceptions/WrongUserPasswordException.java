package com.medplus.tourmanagement.exceptions;

public class WrongUserPasswordException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5275342104073027378L;

}
