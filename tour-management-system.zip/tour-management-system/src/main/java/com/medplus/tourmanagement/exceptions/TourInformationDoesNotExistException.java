package com.medplus.tourmanagement.exceptions;

public class TourInformationDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4895075477366420097L;

}
