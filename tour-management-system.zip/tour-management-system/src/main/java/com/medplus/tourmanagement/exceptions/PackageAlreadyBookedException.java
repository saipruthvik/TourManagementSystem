package com.medplus.tourmanagement.exceptions;

public class PackageAlreadyBookedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
