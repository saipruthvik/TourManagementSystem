package com.medplus.tourmanagement.exceptions;

public class PackageBookingDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7665946894352122578L;

}
