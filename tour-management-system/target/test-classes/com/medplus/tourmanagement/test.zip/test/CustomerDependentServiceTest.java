package com.medplus.tourmanagement.test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medplus.tourmanagement.dto.CustomerDependentDto;
import com.medplus.tourmanagement.exceptions.CustomerDependentDoesNotExistException;
import com.medplus.tourmanagement.service.CustomerDependentService;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class CustomerDependentServiceTest {

	@Autowired
	CustomerDependentService customerDependentService;

	@Test
	@Order(1)
	void testAddCustomerDependentTrue() {
		CustomerDependentDto customerDependentDto = new CustomerDependentDto();
		customerDependentDto.setCustomerId(110001);
		customerDependentDto.setCustomerDependentAge(30);
		customerDependentDto.setCustomerDependentName("mohan");
		assertTrue(customerDependentService.addCustomerDependent(customerDependentDto) != null);
	}

	@Test
	@Order(2)
	void testGetCustomerDependentsListTrue() {
		assertTrue(customerDependentService.getCustomerDependentsList(110001) != null);
	}

	@Test
	@Order(3)
	void testDeleteCustomerDependent() {
		customerDependentService.deleteCustomerDependent(1000);
		assertThrows(CustomerDependentDoesNotExistException.class,
				() -> customerDependentService.deleteCustomerDependent(1000));
	}

}