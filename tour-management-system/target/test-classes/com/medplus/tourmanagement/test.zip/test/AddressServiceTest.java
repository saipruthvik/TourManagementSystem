package com.medplus.tourmanagement.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medplus.tourmanagement.dto.AddressDto;
import com.medplus.tourmanagement.service.AddressServiceImpl;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class AddressServiceTest {

	@Autowired
	AddressServiceImpl addressServiceImpl;

	@Test
	void testAddAddressFalse() {
		AddressDto addressDto = new AddressDto();
		addressDto.setHouseNo("102304");
		addressDto.setCity("hyderabad");
		addressDto.setPincode(500055);
		addressDto.setState("telangana");
		addressDto.setStreet("ramampur");
		addressDto.setCustomerId(110000);
		assertFalse(addressServiceImpl.addAddress(addressDto) == null);
	}

	@Test
	void testAddAddressTrue() {
		AddressDto addressDto = new AddressDto();
		addressDto.setHouseNo("102304");
		addressDto.setCity("hyderabad");
		addressDto.setPincode(500055);
		addressDto.setState("telangana");
		addressDto.setStreet("ramampur");
		addressDto.setCustomerId(110000);
		assertTrue(addressServiceImpl.addAddress(addressDto) != null);
	}

	@Test
	void testGetAddressByCustomerIdServiceFalse() {
		assertFalse(addressServiceImpl.getAddressByCustomerId(110000) == null);
	}

	@Test
	void testGetAddressByCustomerIdServiceTrue() {
		assertTrue(addressServiceImpl.getAddressByCustomerId(110001) != null);
	}

	@Test
	void testUpdateAddressFalse() {
		AddressDto addressDto = new AddressDto();
		addressDto.setHouseNo("102304");
		addressDto.setCity("hyderabad");
		addressDto.setPincode(500055);
		addressDto.setState("telangana");
		addressDto.setStreet("kazeepet");
		addressServiceImpl.updateAddress(addressDto);
		assertFalse(addressServiceImpl.updateAddress(addressDto) == null);
	}

	@Test
	void testUpdateAddressTrue() {
		AddressDto addressDto = new AddressDto();
		addressDto.setHouseNo("102304");
		addressDto.setCity("hyderabad");
		addressDto.setPincode(500055);
		addressDto.setState("telangana");
		addressDto.setStreet("kazeepet");
		assertTrue(addressServiceImpl.updateAddress(addressDto) != null);
	}

	@Test
	void testDeleteAddressFalse() {
		addressServiceImpl.deleteAddress(110000);
		assertFalse(addressServiceImpl.getAddressByCustomerId(110000) != null);

	}

	@Test
	void testDeleteAddressTrue() {
		addressServiceImpl.deleteAddress(110000);
		assertTrue(addressServiceImpl.getAddressByCustomerId(110000) == null);

	}

}